package com.example.model

data class TalkingVideoItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val hindiText: String,
    val photoUri: String,
    val videoUrl: String,
    val voiceGender: String, // "Male" or "Female"
    val voiceName: String, // e.g. "Rohan (Male)", "Priya (Female)"
    val speakingStyle: String, // "Normal", "Motivational", "Emotional", "Funny", "News Anchor"
    val durationMs: Long = 15000L,
    val createdAtMs: Long = System.currentTimeMillis(),
    val isSample: Boolean = false
) {
    val formattedDate: String
        get() {
            val sdf = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
            return sdf.format(java.util.Date(createdAtMs))
        }
}

data class SampleAvatarPhoto(
    val id: String,
    val name: String,
    val photoUrl: String,
    val tag: String
)

data class PresetHindiPrompt(
    val title: String,
    val category: String, // "Motivational", "News", "Funny", "Emotional", "Wisdom"
    val hindiText: String
)
