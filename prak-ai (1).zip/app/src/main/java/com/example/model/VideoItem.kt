package com.example.model

data class Chapter(
    val title: String,
    val timestampMs: Long,
    val summary: String
) {
    val formattedTimestamp: String
        get() = formatTimeMs(timestampMs)
}

data class TranscriptItem(
    val timestampMs: Long,
    val text: String
) {
    val formattedTimestamp: String
        get() = formatTimeMs(timestampMs)
}

data class VideoItem(
    val id: String,
    val title: String,
    val description: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val durationMs: Long,
    val category: String,
    val author: String,
    val chapters: List<Chapter> = emptyList(),
    val transcript: List<TranscriptItem> = emptyList(),
    val isCustom: Boolean = false
) {
    val formattedDuration: String
        get() = formatTimeMs(durationMs)
}

fun formatTimeMs(timeMs: Long): String {
    val totalSeconds = (timeMs / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val hours = minutes / 60
    return if (hours > 0) {
        val remainingMinutes = minutes % 60
        String.format("%d:%02d:%02d", hours, remainingMinutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
