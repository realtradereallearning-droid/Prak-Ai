package com.example.network

import com.example.BuildConfig
import com.example.model.VideoItem
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

data class GeminiRequest(
    @SerializedName("contents") val contents: List<GeminiContent>,
    @SerializedName("systemInstruction") val systemInstruction: GeminiContent? = null
)

data class GeminiContent(
    @SerializedName("parts") val parts: List<GeminiPart>
)

data class GeminiPart(
    @SerializedName("text") val text: String
)

data class GeminiResponse(
    @SerializedName("candidates") val candidates: List<GeminiCandidate>?
)

data class GeminiCandidate(
    @SerializedName("content") val content: GeminiContent?
)

interface GeminiApi {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiNetworkClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GeminiApi::class.java)
    }
}

class GeminiAiRepository {

    private val apiKey: String
        get() = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

    suspend fun generateHindiScript(userTopic: String, speakingStyle: String): String {
        val key = apiKey
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return generateFallbackHindiScript(userTopic, speakingStyle)
        }

        val prompt = """
            You are Prak AI, an expert Hindi script writer for talking photo avatar videos.
            Write a captivating Hindi script (in Devanagari script) based on:
            Topic/Concept: "$userTopic"
            Speaking Style: "$speakingStyle" (Options: Normal, Motivational, Emotional, Funny, News Anchor)
            
            Keep the text expressive, engaging, and suitable for a 15-30 second talking avatar video.
            Return ONLY the Hindi script text without English explanations or markdown titles.
        """.trimIndent()

        return try {
            val request = GeminiRequest(
                contents = listOf(GeminiContent(parts = listOf(GeminiPart(prompt))))
            )
            val response = GeminiNetworkClient.api.generateContent(key, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            reply?.trim() ?: generateFallbackHindiScript(userTopic, speakingStyle)
        } catch (e: Exception) {
            generateFallbackHindiScript(userTopic, speakingStyle)
        }
    }

    private fun generateFallbackHindiScript(topic: String, style: String): String {
        return when (style) {
            "Motivational" -> "अगर आप सफलता पाना चाहते हैं तो आज ही से मेहनत करना शुरू कर दें। $topic के क्षेत्र में आपका हर एक कदम आपको आपकी मंजिल के करीब लाएगा!"
            "News Anchor" -> "नमस्कार! प्राक एआई बुलेटिन में आपका स्वागत है। आज $topic को लेकर एक बड़ी और महत्वपूर्ण जानकारी सामने आ रही है..."
            "Funny" -> "अरे सुनो सुनो! $topic के बारे में सोचने में दिमाग मत लगाओ, वरना चाय भी ठंडी हो जाएगी और काम भी नहीं होगा!"
            "Emotional" -> "जिंदगी में $topic की अहमियत तब समझ आती है जब वक्त निकल जाता है। अपनों के साथ हर लम्हा प्यार से बिताएं।"
            else -> "नमस्कार! आज हम $topic के बारे में बात कर रहे हैं। प्राक एआई की मदद से फोटो को बोलते हुए वीडियो में बदलना अब बेहद आसान है।"
        }
    }

    suspend fun generateVideoSummary(video: VideoItem): String {
        val key = apiKey
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return generateFallbackSummary(video)
        }

        val prompt = """
            You are CineAI, an expert AI video analyst. Provide a comprehensive summary for this video:
            Title: ${video.title}
            Author: ${video.author}
            Category: ${video.category}
            Description: ${video.description}
            
            Please provide:
            1. 💡 **Core Overview**: High-level explanation (2-3 sentences).
            2. 🎯 **Key Takeaways**: 3-4 bullet points.
            3. 🏷️ **Key Concepts & Vocabulary**: Highlight 2-3 important terms or themes explained in this content.
            4. ❓ **Discussion Question**: 1 thought-provoking question for the viewer.
        """.trimIndent()

        return try {
            val request = GeminiRequest(
                contents = listOf(GeminiContent(parts = listOf(GeminiPart(prompt))))
            )
            val response = GeminiNetworkClient.api.generateContent(key, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            reply ?: generateFallbackSummary(video)
        } catch (e: Exception) {
            generateFallbackSummary(video) + "\n\n*(Note: Live AI connect note - ${e.localizedMessage ?: "Using offline AI model"})*"
        }
    }

    suspend fun answerVideoQuestion(video: VideoItem, userQuestion: String, currentTimestampFormatted: String): String {
        val key = apiKey
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return generateFallbackAnswer(video, userQuestion, currentTimestampFormatted)
        }

        val transcriptText = video.transcript.joinToString("\n") { "[${it.formattedTimestamp}] ${it.text}" }
        val prompt = """
            You are CineAI, an intelligent video assistant analyzing the video titled "${video.title}".
            Current playback time: $currentTimestampFormatted.
            Video description: ${video.description}
            Transcript snippets:
            $transcriptText
            
            User Question: "$userQuestion"
            
            Answer concisely and helpfully based on the video context. Mention relevant timestamps if applicable.
        """.trimIndent()

        return try {
            val request = GeminiRequest(
                contents = listOf(GeminiContent(parts = listOf(GeminiPart(prompt))))
            )
            val response = GeminiNetworkClient.api.generateContent(key, request)
            val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            reply ?: generateFallbackAnswer(video, userQuestion, currentTimestampFormatted)
        } catch (e: Exception) {
            generateFallbackAnswer(video, userQuestion, currentTimestampFormatted)
        }
    }

    private fun generateFallbackSummary(video: VideoItem): String {
        return """
            💡 **Core Overview**
            "${video.title}" explores key concepts in ${video.category}. Presented by ${video.author}, it provides a rich visual experience with key narrative milestones.

            🎯 **Key Takeaways**
            • Comprehensive introduction to ${video.title} and core themes.
            • Sequential breakdown across ${video.chapters.size} structured chapters.
            • Highlights key narrative beats and technical insights.

            🏷️ **Key Terms**
            • **Cinematic Rendering**: High-fidelity visual production.
            • **Sequencing**: Clear timestamped progression throughout the media stream.

            ❓ **Discussion Question**
            How do the visual storytelling choices in this video enhance your understanding of the core concept?
        """.trimIndent()
    }

    private fun generateFallbackAnswer(video: VideoItem, question: String, timestamp: String): String {
        return "At $timestamp in '${video.title}', this topic is central to the ${video.category} discussion. Based on the chapter outline, check the section around $timestamp for a detailed demonstration!"
    }
}
