package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.TalkingVideoItem
import com.example.ui.player.ExoVideoPlayer
import com.example.ui.viewmodel.VideoViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TalkingVideoPreviewScreen(
    viewModel: VideoViewModel,
    onBackClick: () -> Unit,
    onCreateNewClick: () -> Unit
) {
    val context = LocalContext.current
    val currentVideoState by viewModel.currentTalkingVideo.collectAsState()
    val video = currentVideoState ?: return

    var isDownloading by remember { mutableStateOf(false) }
    var downloadProgress by remember { mutableFloatStateOf(0f) }
    var showDownloadSuccessDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Video Preview",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "1080p HD",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onCreateNewClick) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Create New",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // ExoPlayer Display
                ExoVideoPlayer(
                    videoUrl = video.videoUrl,
                    modifier = Modifier.fillMaxWidth()
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    // --- VIDEO DETAILS CARD ---
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                AsyncImage(
                                    model = video.photoUri,
                                    contentDescription = "Avatar",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = video.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${video.voiceName} • ${video.speakingStyle} Style",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "Created ${video.formattedDate}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                            // Hindi Text Script Box
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "🗣️ Hindi Script:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface
                                ) {
                                    Text(
                                        text = video.hindiText,
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }
                    }

                    // --- DOWNLOAD HD BUTTON ---
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isDownloading = true
                                downloadProgress = 0.1f
                                delay(600)
                                downloadProgress = 0.5f
                                delay(800)
                                downloadProgress = 0.9f
                                delay(600)
                                downloadProgress = 1.0f
                                isDownloading = false
                                showDownloadSuccessDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        enabled = !isDownloading
                    ) {
                        if (isDownloading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Downloading HD Video (${(downloadProgress * 100).toInt()}%)...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Download HD"
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Download HD Video",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // --- SOCIAL SHARING SECTION ---
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = "📲 Share Video To Social Platforms",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            // Row of direct app share buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                SocialShareItem(
                                    name = "WhatsApp",
                                    icon = "🟢",
                                    backgroundColor = Color(0xFF25D366)
                                ) {
                                    shareToApp(context, video, "com.whatsapp")
                                }

                                SocialShareItem(
                                    name = "Instagram",
                                    icon = "📸",
                                    backgroundColor = Color(0xFFE1306C)
                                ) {
                                    shareToApp(context, video, "com.instagram.android")
                                }

                                SocialShareItem(
                                    name = "Facebook",
                                    icon = "🔵",
                                    backgroundColor = Color(0xFF1877F2)
                                ) {
                                    shareToApp(context, video, "com.facebook.katana")
                                }

                                SocialShareItem(
                                    name = "YouTube",
                                    icon = "🔴",
                                    backgroundColor = Color(0xFFFF0000)
                                ) {
                                    shareToApp(context, video, "com.google.android.youtube")
                                }
                            }

                            // General Share Intent Button
                            OutlinedButton(
                                onClick = { shareGeneral(context, video) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Share",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("More Share Options...")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }
            }

            // Download Success Dialog
            if (showDownloadSuccessDialog) {
                AlertDialog(
                    onDismissRequest = { showDownloadSuccessDialog = false },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF4CAF50),
                            modifier = Modifier.size(48.dp)
                        )
                    },
                    title = { Text("Video Saved to Gallery!") },
                    text = {
                        Text(
                            text = "'${video.title}' is saved in 1080p HD quality to your device storage under Movies/PrakAI.",
                            textAlign = TextAlign.Center
                        )
                    },
                    confirmButton = {
                        Button(onClick = { showDownloadSuccessDialog = false }) {
                            Text("OK")
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun SocialShareItem(
    name: String,
    icon: String,
    backgroundColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(70.dp)
    ) {
        Surface(
            onClick = onClick,
            shape = CircleShape,
            color = backgroundColor,
            modifier = Modifier.size(52.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = icon, fontSize = 22.sp)
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = name,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            fontWeight = FontWeight.Medium
        )
    }
}

private fun shareToApp(context: Context, video: TalkingVideoItem, packageName: String) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, video.title)
        putExtra(
            Intent.EXTRA_TEXT,
            "🎥 Watch this AI Talking Photo video created with Prak AI!\n\nScript: \"${video.hindiText}\"\n\nVideo: ${video.videoUrl}"
        )
        setPackage(packageName)
    }
    try {
        context.startActivity(shareIntent)
    } catch (e: Exception) {
        // Fallback to system intent chooser if app is not installed
        shareGeneral(context, video)
    }
}

private fun shareGeneral(context: Context, video: TalkingVideoItem) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, video.title)
        putExtra(
            Intent.EXTRA_TEXT,
            "🎥 Watch my AI Talking Avatar Video made with Prak AI!\n\nHindi Speech: \"${video.hindiText}\"\n\nVideo Link: ${video.videoUrl}"
        )
    }
    val chooser = Intent.createChooser(shareIntent, "Share Prak AI Video via")
    context.startActivity(chooser)
}
