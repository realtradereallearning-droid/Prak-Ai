package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF38BDF8)
val CyanSecondary = Color(0xFF0284C7)
val IndigoAccent = Color(0xFF818CF8)
val RoseAccent = Color(0xFFF43F5E)
val AmberAccent = Color(0xFFF59E0B)

val MidnightBackground = Color(0xFF090D16)
val MidnightSurface = Color(0xFF131927)
val MidnightSurfaceVariant = Color(0xFF1E293B)
val MidnightSurfaceHighlight = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

