package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleAvatarRepository
import com.example.data.SampleVideoRepository
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.TalkingVideoEntity
import com.example.data.local.WatchHistoryEntity
import com.example.model.TalkingVideoItem
import com.example.model.VideoItem
import com.example.model.formatTimeMs
import com.example.network.GeminiAiRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "USER" or "AI"
    val text: String,
    val timestamp: String = formatTimeMs(System.currentTimeMillis())
)

class VideoViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val videoDao = db.videoDao()
    private val geminiRepo = GeminiAiRepository()

    // --- PRAK AI TALKING AVATAR CREATION STATES ---
    private val _selectedPhotoUri = MutableStateFlow<String?>(SampleAvatarRepository.sampleAvatars.first().photoUrl)
    val selectedPhotoUri = _selectedPhotoUri.asStateFlow()

    private val _hindiText = MutableStateFlow(SampleAvatarRepository.presetHindiPrompts.first().hindiText)
    val hindiText = _hindiText.asStateFlow()

    private val _voiceGender = MutableStateFlow("Male")
    val voiceGender = _voiceGender.asStateFlow()

    private val _voiceName = MutableStateFlow("Aarav (Male)")
    val voiceName = _voiceName.asStateFlow()

    private val _speakingStyle = MutableStateFlow("Motivational")
    val speakingStyle = _speakingStyle.asStateFlow()

    private val _isGeneratingTalkingVideo = MutableStateFlow(false)
    val isGeneratingTalkingVideo = _isGeneratingTalkingVideo.asStateFlow()

    private val _generationProgress = MutableStateFlow(0f)
    val generationProgress = _generationProgress.asStateFlow()

    private val _generationStepText = MutableStateFlow("")
    val generationStepText = _generationStepText.asStateFlow()

    private val _currentTalkingVideo = MutableStateFlow<TalkingVideoItem?>(SampleAvatarRepository.sampleVideos.first())
    val currentTalkingVideo = _currentTalkingVideo.asStateFlow()

    private val _isAutoGeneratingScript = MutableStateFlow(false)
    val isAutoGeneratingScript = _isAutoGeneratingScript.asStateFlow()

    // Room DB Observations for Saved Talking Videos
    val savedTalkingVideos: StateFlow<List<TalkingVideoItem>> = videoDao.getAllTalkingVideos()
        .map { list ->
            list.map { entity ->
                TalkingVideoItem(
                    id = entity.id,
                    title = entity.title,
                    hindiText = entity.hindiText,
                    photoUri = entity.photoUri,
                    videoUrl = entity.videoUrl,
                    voiceGender = entity.voiceGender,
                    voiceName = entity.voiceName,
                    speakingStyle = entity.speakingStyle,
                    durationMs = entity.durationMs,
                    createdAtMs = entity.createdAtMs
                )
            }
        }.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

    // --- PRAK AI SETTERS ---
    fun setSelectedPhotoUri(uri: String) {
        _selectedPhotoUri.value = uri
    }

    fun setHindiText(text: String) {
        _hindiText.value = text
    }

    fun setVoiceGender(gender: String) {
        _voiceGender.value = gender
        _voiceName.value = if (gender == "Male") "Aarav (Male)" else "Ananya (Female)"
    }

    fun setVoiceName(name: String) {
        _voiceName.value = name
    }

    fun setSpeakingStyle(style: String) {
        _speakingStyle.value = style
    }

    fun selectTalkingVideo(video: TalkingVideoItem) {
        _currentTalkingVideo.value = video
    }

    fun generateHindiScriptWithGemini(topic: String) {
        if (topic.isBlank()) return
        viewModelScope.launch {
            _isAutoGeneratingScript.value = true
            val script = geminiRepo.generateHindiScript(topic, _speakingStyle.value)
            _hindiText.value = script
            _isAutoGeneratingScript.value = false
        }
    }

    fun generateTalkingVideo(onSuccess: (TalkingVideoItem) -> Unit) {
        val photo = _selectedPhotoUri.value ?: SampleAvatarRepository.sampleAvatars.first().photoUrl
        val text = _hindiText.value.ifBlank { "नमस्कार! प्राक एआई में आपका स्वागत है।" }
        val gender = _voiceGender.value
        val voice = _voiceName.value
        val style = _speakingStyle.value

        viewModelScope.launch {
            _isGeneratingTalkingVideo.value = true
            _generationProgress.value = 0.1f
            _generationStepText.value = "📷 Analyzing Photo Facial Landmarks..."
            delay(1200)

            _generationProgress.value = 0.35f
            _generationStepText.value = "🎙️ Synthesizing $voice Hindi Speech ($style style)..."
            delay(1500)

            _generationProgress.value = 0.70f
            _generationStepText.value = "🎬 Aligning Lip-Sync & Expression Animation..."
            delay(1500)

            _generationProgress.value = 0.95f
            _generationStepText.value = "✨ Rendering HD Talking Avatar Video..."
            delay(1000)

            // Select video sample stream based on voice/style
            val videoSampleUrl = when (style) {
                "News Anchor" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                "Motivational" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"
                "Funny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4"
                "Emotional" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4"
                else -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"
            }

            val newVideo = TalkingVideoItem(
                id = "prak_video_${System.currentTimeMillis()}",
                title = if (text.length > 25) text.take(25) + "..." else text,
                hindiText = text,
                photoUri = photo,
                videoUrl = videoSampleUrl,
                voiceGender = gender,
                voiceName = voice,
                speakingStyle = style,
                durationMs = 25000L,
                createdAtMs = System.currentTimeMillis()
            )

            // Save to Room DB
            videoDao.insertTalkingVideo(
                TalkingVideoEntity(
                    id = newVideo.id,
                    title = newVideo.title,
                    hindiText = newVideo.hindiText,
                    photoUri = newVideo.photoUri,
                    videoUrl = newVideo.videoUrl,
                    voiceGender = newVideo.voiceGender,
                    voiceName = newVideo.voiceName,
                    speakingStyle = newVideo.speakingStyle,
                    durationMs = newVideo.durationMs,
                    createdAtMs = newVideo.createdAtMs
                )
            )

            _currentTalkingVideo.value = newVideo
            _generationProgress.value = 1.0f
            _generationStepText.value = "🎉 Video Generation Complete!"
            delay(500)
            _isGeneratingTalkingVideo.value = false

            onSuccess(newVideo)
        }
    }

    fun deleteTalkingVideo(id: String) {
        viewModelScope.launch {
            videoDao.deleteTalkingVideo(id)
        }
    }

    // --- OTHER PLAYER STATES ---
    private val _customVideos = MutableStateFlow<List<VideoItem>>(emptyList())
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    val allVideos: StateFlow<List<VideoItem>> = combine(
        _customVideos,
        _searchQuery,
        _selectedCategory
    ) { customList, query, category ->
        val fullList = SampleVideoRepository.sampleVideos + customList
        fullList.filter { video ->
            val matchesCategory = (category == "All" || video.category.equals(category, ignoreCase = true))
            val matchesQuery = query.isBlank() ||
                    video.title.contains(query, ignoreCase = true) ||
                    video.description.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SampleVideoRepository.sampleVideos)

    private val _currentVideo = MutableStateFlow<VideoItem?>(SampleVideoRepository.sampleVideos.firstOrNull())
    val currentVideo = _currentVideo.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs = _currentPositionMs.asStateFlow()

    private val _videoDurationMs = MutableStateFlow(1L)
    val videoDurationMs = _videoDurationMs.asStateFlow()

    private val _seekToMs = MutableStateFlow<Long?>(null)
    val seekToMs = _seekToMs.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab = _selectedTab.asStateFlow()

    private val _aiSummaryState = MutableStateFlow<String?>(null)
    val aiSummaryState = _aiSummaryState.asStateFlow()

    private val _isGeneratingSummary = MutableStateFlow(false)
    val isGeneratingSummary = _isGeneratingSummary.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading = _isChatLoading.asStateFlow()

    val bookmarks: StateFlow<List<BookmarkEntity>> = videoDao.getAllBookmarks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val watchHistory: StateFlow<List<WatchHistoryEntity>> = videoDao.getWatchHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setSelectedTab(tabIndex: Int) {
        _selectedTab.value = tabIndex
    }

    fun selectVideo(video: VideoItem) {
        _currentVideo.value = video
        _aiSummaryState.value = null
        _chatMessages.value = emptyList()
        _seekToMs.value = 0L
        loadAiSummaryForVideo(video)
    }

    fun updatePlaybackPosition(posMs: Long, durationMs: Long) {
        _currentPositionMs.value = posMs
        _videoDurationMs.value = durationMs
    }

    fun seekToPosition(timestampMs: Long) {
        _seekToMs.value = timestampMs
    }

    fun clearSeekTrigger() {
        _seekToMs.value = null
    }

    fun loadAiSummaryForVideo(video: VideoItem) {
        viewModelScope.launch {
            _isGeneratingSummary.value = true
            val summary = geminiRepo.generateVideoSummary(video)
            _aiSummaryState.value = summary
            _isGeneratingSummary.value = false
        }
    }

    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return
        val video = _currentVideo.value
        val userMessage = ChatMessage(sender = "USER", text = userText)
        _chatMessages.value = _chatMessages.value + userMessage

        viewModelScope.launch {
            _isChatLoading.value = true
            val aiReply = if (video != null) {
                geminiRepo.answerVideoQuestion(video, userText, formatTimeMs(_currentPositionMs.value))
            } else {
                geminiRepo.generateHindiScript(userText, _speakingStyle.value)
            }
            val aiMessage = ChatMessage(sender = "AI", text = aiReply)
            _chatMessages.value = _chatMessages.value + aiMessage
            _isChatLoading.value = false
        }
    }

    fun addNoteBookmark(noteText: String, customTimeMs: Long? = null) {
        val video = _currentVideo.value ?: return
        val posMs = customTimeMs ?: _currentPositionMs.value
        val formatted = formatTimeMs(posMs)

        viewModelScope.launch {
            videoDao.insertBookmark(
                BookmarkEntity(
                    videoId = video.id,
                    videoTitle = video.title,
                    timestampMs = posMs,
                    timestampFormatted = formatted,
                    noteText = if (noteText.isBlank()) "Bookmark at $formatted" else noteText
                )
            )
        }
    }

    fun deleteBookmark(bookmarkId: Long) {
        viewModelScope.launch {
            videoDao.deleteBookmark(bookmarkId)
        }
    }

    fun addCustomVideoUrl(title: String, url: String, category: String, thumbnailUrl: String? = null) {
        if (title.isBlank() || url.isBlank()) return
        val finalThumbnail = if (!thumbnailUrl.isNullOrBlank()) thumbnailUrl else "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=800&q=80"
        val newVideo = VideoItem(
            id = "custom_${System.currentTimeMillis()}",
            title = title,
            description = "Custom video imported from URL: $url",
            videoUrl = url,
            thumbnailUrl = finalThumbnail,
            durationMs = 300000L,
            category = category.ifBlank { "Custom Stream" },
            author = "User Import",
            isCustom = true
        )
        _customVideos.value = _customVideos.value + newVideo
        selectVideo(newVideo)
    }

    fun clearWatchHistory() {
        viewModelScope.launch {
            videoDao.clearHistory()
        }
    }
}
