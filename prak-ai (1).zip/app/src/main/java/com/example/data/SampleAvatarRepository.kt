package com.example.data

import com.example.model.PresetHindiPrompt
import com.example.model.SampleAvatarPhoto
import com.example.model.TalkingVideoItem

object SampleAvatarRepository {

    val sampleAvatars = listOf(
        SampleAvatarPhoto(
            id = "avatar_1",
            name = "Aarav (News Anchor)",
            photoUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
            tag = "News & Media"
        ),
        SampleAvatarPhoto(
            id = "avatar_2",
            name = "Ananya (Motivational)",
            photoUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&q=80",
            tag = "Motivation"
        ),
        SampleAvatarPhoto(
            id = "avatar_3",
            name = "Rohan (Creator)",
            photoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&q=80",
            tag = "Vlog & Comedy"
        ),
        SampleAvatarPhoto(
            id = "avatar_4",
            name = "Kavya (Teacher)",
            photoUrl = "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=800&q=80",
            tag = "Education"
        ),
        SampleAvatarPhoto(
            id = "avatar_5",
            name = "Vikram (Storyteller)",
            photoUrl = "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=800&q=80",
            tag = "Poetry & Drama"
        )
    )

    val presetHindiPrompts = listOf(
        PresetHindiPrompt(
            title = "प्रेरणादायक संदेश (Motivational)",
            category = "Motivational",
            hindiText = "सफलता उन्हीं को मिलती है जिनके सपनों में जान होती है, पंखों से कुछ नहीं होता हौसलों से उड़ान होती है। अपने लक्ष्य पर अडिग रहें!"
        ),
        PresetHindiPrompt(
            title = "आज का मुख्य समाचार (News Anchor)",
            category = "News Anchor",
            hindiText = "नमस्कार! प्राक एआई समाचार में आपका स्वागत है। आज विज्ञान और तकनीक की दुनिया से एक बड़ी खबर सामने आ रही है..."
        ),
        PresetHindiPrompt(
            title = "मजेदार जोक (Comedy)",
            category = "Funny",
            hindiText = "अरे भैया, जिंदगी में टेंशन इतनी बढ़ गई है कि चाय की दुकान वाला भी पूछने लगा है - भैया चीनी कम रखूं या सोच कम करूं?"
        ),
        PresetHindiPrompt(
            title = "भावुक शायरी (Emotional)",
            category = "Emotional",
            hindiText = "खामोशियां भी बोलती हैं, बस सुनने वाला होना चाहिए। जिंदगी के हर लम्हे को खुलकर जियो, क्या पता कल हो न हो..."
        ),
        PresetHindiPrompt(
            title = "दैनिक सुविचार (Wisdom)",
            category = "Normal",
            hindiText = "सकारात्मक सोच इंसान को हर कठिनाई से उबरने की शक्ति देती है। आज के दिन की शुरुआत एक मुस्कान के साथ करें।"
        )
    )

    val sampleVideos = listOf(
        TalkingVideoItem(
            id = "demo_1",
            title = "Prak AI News Bulletin",
            hindiText = "नमस्कार! प्राक एआई समाचार में आपका स्वागत है। तकनीक के इस नए दौर में एआई फोटो से वीडियो बनाना अब बेहद आसान हो गया है।",
            photoUri = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            voiceGender = "Male",
            voiceName = "Aarav (Male)",
            speakingStyle = "News Anchor",
            durationMs = 596000L,
            isSample = true
        ),
        TalkingVideoItem(
            id = "demo_2",
            title = "Motivational Hindi Speech",
            hindiText = "सफलता का कोई शॉर्टकट नहीं होता। जब तक आप प्रयास करना नहीं छोड़ते, तब तक आप हार नहीं सकते!",
            photoUri = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&q=80",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            voiceGender = "Female",
            voiceName = "Ananya (Female)",
            speakingStyle = "Motivational",
            durationMs = 734000L,
            isSample = true
        ),
        TalkingVideoItem(
            id = "demo_3",
            title = "Funny Comedy Reel Avatar",
            hindiText = "अरे भैया! चाय पीने का मजा तो सिर्फ ठंड में है, वो भी दोस्त के पैसे पर!",
            photoUri = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=800&q=80",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            voiceGender = "Male",
            voiceName = "Rohan (Male)",
            speakingStyle = "Funny",
            durationMs = 888000L,
            isSample = true
        )
    )
}
