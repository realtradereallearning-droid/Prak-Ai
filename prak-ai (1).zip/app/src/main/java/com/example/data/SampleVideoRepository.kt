package com.example.data

import com.example.model.Chapter
import com.example.model.TranscriptItem
import com.example.model.VideoItem

object SampleVideoRepository {
    val sampleVideos = listOf(
        VideoItem(
            id = "video_1",
            title = "Big Buck Bunny 4K Cinematic",
            description = "A large and lovable rabbit's quiet day is rudely interrupted by three bullying rodents. Produced by the Blender Foundation using open-source tools.",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=800&q=80",
            durationMs = 596000L, // ~9 min 56s
            category = "Animation & 3D",
            author = "Blender Open Movie Project",
            chapters = listOf(
                Chapter("Peaceful Morning in the Forest", 0L, "Bunny wakes up and enjoys nature surrounded by butterflies and birds."),
                Chapter("Arrival of the Naughty Rodents", 120000L, "Frank, Rinky, and Gamera start bothering forest creatures."),
                Chapter("Bunny's Master Trap Strategy", 270000L, "Bunny plans a clever set of traps using forest vines and boulders."),
                Chapter("The Great Forest Showdown", 420000L, "Bunny executes his retribution plan with hilarious outcomes."),
                Chapter("Conclusion & Epilogue", 530000L, "Peace is restored to the woodland kingdom.")
            ),
            transcript = listOf(
                TranscriptItem(10000L, "Birds are singing peacefully across the green forest canopy."),
                TranscriptItem(60000L, "Big Buck Bunny gently smells a delicate yellow flower."),
                TranscriptItem(130000L, "The cheeky flying squirrel throws a apple at Big Buck Bunny."),
                TranscriptItem(280000L, "Bunny calculates the exact angle and tension of the tree rope."),
                TranscriptItem(450000L, "The catapult releases and sends the target flying across the lake.")
            )
        ),
        VideoItem(
            id = "video_2",
            title = "Tears of Steel - Sci-Fi VFX Showcase",
            description = "In a dystopian future, a group of scientists and soldiers gather at Amsterdam's Oude Kerk to prevent a robotic apocalypse.",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&q=80",
            durationMs = 734000L, // ~12 min 14s
            category = "Sci-Fi & AI",
            author = "Blender Foundation Institute",
            chapters = listOf(
                Chapter("Intro: The Fallen City of Amsterdam", 0L, "A dramatic look at futuristic Amsterdam under siege by cybernetic robots."),
                Chapter("The Memory Extraction Rig", 150000L, "Scientists recalibrate human memory chips to find the override key."),
                Chapter("Robotic Patrol Invasion", 330000L, "Sentry mechs assault the church sanctuary headquarters."),
                Chapter("Celia's Cybernetic Overdrive", 510000L, "The emotional truth behind the robot outbreak is revealed."),
                Chapter("The Final Signal Override", 650000L, "Uploading the peace key before the city defence collapses.")
            ),
            transcript = listOf(
                TranscriptItem(15000L, "Initializing high-voltage neural link to the central server."),
                TranscriptItem(180000L, "We must locate Celia's core memory bank before 0300 hours."),
                TranscriptItem(350000L, "Incoming threat! Heavy mech units detected at the North Gate."),
                TranscriptItem(530000L, "The cybernetic arm was never meant to destroy us.")
            )
        ),
        VideoItem(
            id = "video_3",
            title = "Sintel - Open Fantasy Adventure",
            description = "A lonely girl named Sintel rescues a baby dragon, named Scales. When Scales is snatched by an adult dragon, Sintel embarks on a dangerous quest across the realm.",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&q=80",
            durationMs = 888000L, // ~14 min 48s
            category = "Animation & 3D",
            author = "Durian Open Movie Project",
            chapters = listOf(
                Chapter("Snowy Mountain Blizzard", 0L, "Sintel wanders through a blinding snowstorm seeking a wise shaman."),
                Chapter("Finding Baby Scales", 180000L, "A flashback shows Sintel rescuing and nursing a injured baby dragon."),
                Chapter("The Dragon Abduction", 360000L, "A colossal sky shadow snatches Scales away into the clouds."),
                Chapter("Quest Across Desert & Sea", 500000L, "Sintel trains in martial arts and crosses desert dunes in search."),
                Chapter("The Colosseum Clash & Discovery", 700000L, "A tragic fight inside the dragon's volcanic lair.")
            ),
            transcript = listOf(
                TranscriptItem(20000L, "The cold wind cuts through my armor like ice blades."),
                TranscriptItem(200000L, "Here little dragon, eat this piece of dried meat."),
                TranscriptItem(380000L, "Scales! Hold on! I will come for you!"),
                TranscriptItem(720000L, "Looking into the beast's eyes, a terrible realization sets in.")
            )
        ),
        VideoItem(
            id = "video_4",
            title = "Generative AI & LLM Architecture Explained",
            description = "A deep dive into how Transformer Neural Networks, Self-Attention Mechanisms, and Large Language Models work under the hood.",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
            durationMs = 150000L, // ~2 min 30s
            category = "AI & Science",
            author = "AI Research Lab",
            chapters = listOf(
                Chapter("Introduction to Neural Vectors", 0L, "Understanding embeddings and high-dimensional semantic spaces."),
                Chapter("Self-Attention Matrix Mechanics", 45000000L / 1000L, "How Query, Key, and Value matrices weight token importance."),
                Chapter("Generative Decoding & Temperature", 90000000L / 1000L, "Sampling techniques for output token generation.")
            ),
            transcript = listOf(
                TranscriptItem(5000L, "Welcome to the fundamental mechanics of Large Language Models."),
                TranscriptItem(48000L, "Self-attention enables the model to connect contextual references dynamically."),
                TranscriptItem(95000L, "Temperature scaling controls creativity versus deterministic outputs.")
            )
        ),
        VideoItem(
            id = "video_5",
            title = "Space Odyssey: Nebulas & Deep Cosmos",
            description = "Breathtaking 4K deep space imagery captured by James Webb Space Telescope with ambient cosmic synthesizer soundscapes.",
            videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80",
            durationMs = 180000L,
            category = "Science & Nature",
            author = "Cosmic Vision Media",
            chapters = listOf(
                Chapter("Carina Nebula Pillars", 0L, "Infrared light revealing star-forming nurseries."),
                Chapter("Gravitational Lensing Galaxies", 60000L, "Massive galaxy clusters bending starlight across billions of light years."),
                Chapter("Exoplanet Atmosphere Spectra", 120000L, "Detecting water vapor and methane in distant worlds.")
            ),
            transcript = listOf(
                TranscriptItem(10000L, "Infrared sensors cut through thick cosmic dust clouds."),
                TranscriptItem(65000L, "Light from ancient galaxies warped by dark matter gravity wells."),
                TranscriptItem(125000L, "Atmospheric absorption lines confirm atmospheric molecular signatures.")
            )
        )
    )

    fun getVideoById(id: String): VideoItem? {
        return sampleVideos.find { it.id == id }
    }
}
