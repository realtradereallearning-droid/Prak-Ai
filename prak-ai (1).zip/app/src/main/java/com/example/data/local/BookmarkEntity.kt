package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val videoTitle: String,
    val timestampMs: Long,
    val timestampFormatted: String,
    val noteText: String,
    val createdAtMs: Long = System.currentTimeMillis()
)
