package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "talking_videos")
data class TalkingVideoEntity(
    @PrimaryKey val id: String,
    val title: String,
    val hindiText: String,
    val photoUri: String,
    val videoUrl: String,
    val voiceGender: String,
    val voiceName: String,
    val speakingStyle: String,
    val durationMs: Long,
    val createdAtMs: Long
)
