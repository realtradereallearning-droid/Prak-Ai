package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val videoId: String,
    val videoTitle: String,
    val thumbnailUrl: String,
    val lastPositionMs: Long,
    val durationMs: Long,
    val lastWatchedAtMs: Long = System.currentTimeMillis()
)
