package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.screens.*
import com.example.ui.theme.CineAITheme
import com.example.ui.viewmodel.VideoViewModel

enum class NavScreen(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    CREATE("create", "Studio", Icons.Default.Videocam),
    PREVIEW("preview", "Preview", Icons.Default.PlayCircle),
    EXPLORE("explore", "Explore", Icons.Default.Explore),
    HISTORY("history", "History", Icons.Default.History),
    ASK_AI("chat", "AI Writer", Icons.Default.AutoAwesome)
}

class MainActivity : ComponentActivity() {

    private val viewModel: VideoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CineAITheme {
                var currentScreen by remember { mutableStateOf(NavScreen.CREATE) }

                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.onSurface
                        ) {
                            NavScreen.entries.forEach { screen ->
                                NavigationBarItem(
                                    selected = currentScreen == screen,
                                    onClick = { currentScreen = screen },
                                    icon = {
                                        Icon(
                                            imageVector = screen.icon,
                                            contentDescription = screen.label
                                        )
                                    },
                                    label = { Text(screen.label) }
                                )
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                            when (screen) {
                                NavScreen.CREATE -> CreateTalkingVideoScreen(
                                    viewModel = viewModel,
                                    onVideoGenerated = { generated ->
                                        viewModel.selectTalkingVideo(generated)
                                        currentScreen = NavScreen.PREVIEW
                                    }
                                )
                                NavScreen.PREVIEW -> TalkingVideoPreviewScreen(
                                    viewModel = viewModel,
                                    onBackClick = {
                                        currentScreen = NavScreen.CREATE
                                    },
                                    onCreateNewClick = {
                                        currentScreen = NavScreen.CREATE
                                    }
                                )
                                NavScreen.EXPLORE -> ExploreTemplatesScreen(
                                    viewModel = viewModel,
                                    onSelectSampleVideo = { sample ->
                                        viewModel.selectTalkingVideo(sample)
                                        currentScreen = NavScreen.PREVIEW
                                    },
                                    onTryTemplate = { photoUrl, promptText, style ->
                                        viewModel.setSelectedPhotoUri(photoUrl)
                                        viewModel.setHindiText(promptText)
                                        viewModel.setSpeakingStyle(style)
                                        currentScreen = NavScreen.CREATE
                                    }
                                )
                                NavScreen.HISTORY -> CreationHistoryScreen(
                                    viewModel = viewModel,
                                    onSelectVideo = { video ->
                                        viewModel.selectTalkingVideo(video)
                                        currentScreen = NavScreen.PREVIEW
                                    },
                                    onCreateNewClick = {
                                        currentScreen = NavScreen.CREATE
                                    }
                                )
                                NavScreen.ASK_AI -> AiChatScreen(
                                    viewModel = viewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
